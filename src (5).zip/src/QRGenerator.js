import React, { useState, useEffect } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { collection, query, where, getDocs, updateDoc, doc, onSnapshot } from "firebase/firestore";
import { db } from "./firebase";
import "./QRGenerator.css";

/**
 * QR GENERATOR COMPONENT
 * 
 * Owner-only menu untuk:
 * 1. Display QR code untuk di-share ke viewer
 * 2. Manage pending approval requests
 * 3. See device details dari viewer (device type, OS, browser)
 * 4. Accept/Reject requests
 * 5. See approved viewers list
 * 
 * Real-time updates: auto-refresh when data changes
 */

export default function QRGenerator({ user, onBack }) {
  const [qrValue, setQrValue] = useState(null);
  const [groupId, setGroupId] = useState(null);
  const [pendingRequests, setPendingRequests] = useState([]);
  const [approvedViewers, setApprovedViewers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showQR, setShowQR] = useState(false);

  // Load group data dengan real-time listener
  useEffect(() => {
    loadGroupData();
  }, [user]);

  const loadGroupData = async () => {
    try {
      if (!user.groupId) {
        setLoading(false);
        return;
      }

      console.log("Loading group data for:", user.groupId);

      // Set up real-time listener
      const groupsRef = collection(db, "groups");
      const q = query(groupsRef, where("groupId", "==", user.groupId));
      
      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        if (!querySnapshot.empty) {
          const groupDoc = querySnapshot.docs[0];
          const groupData = groupDoc.data();

          console.log("Group data updated:", groupData);

          setGroupId(groupData.groupId);
          setQrValue(`yubul://group/${groupData.groupId}`);
          
          // Separate pending dan approved
          const pending = groupData.pendingApprovals?.filter(r => r.status === "pending") || [];
          const approved = groupData.pendingApprovals?.filter(r => r.status === "approved") || [];
          
          setPendingRequests(pending);
          setApprovedViewers(approved);
        }
        
        setLoading(false);
      });

      return () => unsubscribe();
    } catch (err) {
      console.error("Error loading group:", err);
      setError("Error loading group data");
      setLoading(false);
    }
  };

  // Accept request
  const handleAccept = async (viewerUid, requestIndex) => {
    try {
      setLoading(true);
      
      if (!user.groupId) {
        throw new Error("Group not found");
      }

      const groupsRef = collection(db, "groups");
      const q = query(groupsRef, where("groupId", "==", user.groupId));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        const groupDoc = querySnapshot.docs[0];
        const groupData = groupDoc.data();
        
        // Update pending approval status
        const updated = groupData.pendingApprovals.map((req, i) =>
          i === requestIndex ? { ...req, status: "approved" } : req
        );
        
        // Add viewer to members
        const members = [...(groupData.members || []), viewerUid];
        
        // Update group document
        await updateDoc(doc(db, "groups", groupDoc.id), {
          pendingApprovals: updated,
          members: members,
          memberCount: members.length,
          updatedAt: new Date(),
        });

        console.log("✅ Viewer approved!");

        // Update viewer document
        const viewerRef = doc(db, "users", viewerUid);
        await updateDoc(viewerRef, {
          approvalStatus: "approved",
          approvalApprovedAt: new Date(),
          updatedAt: new Date(),
        });

        setError(null);
      }
      
      setLoading(false);
    } catch (err) {
      console.error("Error accepting:", err);
      setError("❌ Error: " + err.message);
      setLoading(false);
    }
  };

  // Reject request
  const handleReject = async (viewerUid, requestIndex) => {
    try {
      setLoading(true);
      
      if (!user.groupId) {
        throw new Error("Group not found");
      }

      const groupsRef = collection(db, "groups");
      const q = query(groupsRef, where("groupId", "==", user.groupId));
      const querySnapshot = await getDocs(q);
      
      if (!querySnapshot.empty) {
        const groupDoc = querySnapshot.docs[0];
        const groupData = groupDoc.data();
        
        // Update pending approval status
        const updated = groupData.pendingApprovals.map((req, i) =>
          i === requestIndex ? { ...req, status: "rejected" } : req
        );
        
        // Update group document
        await updateDoc(doc(db, "groups", groupDoc.id), {
          pendingApprovals: updated,
          updatedAt: new Date(),
        });

        console.log("❌ Viewer rejected!");

        // Update viewer document
        const viewerRef = doc(db, "users", viewerUid);
        await updateDoc(viewerRef, {
          approvalStatus: "rejected",
          updatedAt: new Date(),
        });

        setError(null);
      }
      
      setLoading(false);
    } catch (err) {
      console.error("Error rejecting:", err);
      setError("❌ Error: " + err.message);
      setLoading(false);
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="qr-generator-page">
        <header className="qr-header">
          <button onClick={onBack} className="btn-back">← Back</button>
          <h1>🔐 Generate QR Code</h1>
          <div></div>
        </header>
        <div className="loading-container">
          <div className="spinner"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="qr-generator-page">
      {/* HEADER */}
      <header className="qr-header">
        <button onClick={onBack} className="btn-back">← Back</button>
        <h1>🔐 Generate QR Code</h1>
        <div></div>
      </header>

      {/* ERROR MESSAGE */}
      {error && <div className="error-banner">{error}</div>}

      {/* MAIN CONTENT */}
      <main className="qr-content">
        
        {/* SECTION 1: QR CODE */}
        <section className="qr-section">
          <div className="section-header">
            <h2>📱 QR Code untuk Viewer</h2>
            <p className="section-description">Share QR code ini ke partner agar mereka bisa scan dan request access</p>
          </div>

          {qrValue ? (
            <div className="qr-display-container">
              {showQR && (
                <div className="qr-display">
                  <QRCodeCanvas
                    value={qrValue}
                    size={250}
                    level="H"
                    includeMargin={true}
                    style={{ border: "10px solid #fff", borderRadius: "10px" }}
                  />
                  <div className="qr-info">
                    <p><strong>Group ID:</strong></p>
                    <p className="group-id">{groupId}</p>
                    <p className="qr-hint">📸 Share QR code via WhatsApp/SMS/Email</p>
                  </div>
                </div>
              )}
              
              <button
                onClick={() => setShowQR(!showQR)}
                className="btn-toggle-qr"
              >
                {showQR ? "Hide QR Code" : "Show QR Code"}
              </button>
            </div>
          ) : (
            <div className="no-group">
              <p>❌ No group created yet</p>
              <p className="hint">You need to have a group to generate QR code</p>
            </div>
          )}
        </section>

        {/* SECTION 2: PENDING REQUESTS */}
        <section className="qr-section">
          <div className="section-header">
            <h2>⏳ Pending Requests ({pendingRequests.length})</h2>
            <p className="section-description">Review viewer requests and approve/reject them</p>
          </div>

          {pendingRequests.length === 0 ? (
            <div className="empty-state">
              <p className="empty-icon">📋</p>
              <p className="empty-text">No pending requests yet</p>
              <p className="empty-hint">Share QR code to partner to start receiving requests</p>
            </div>
          ) : (
            <div className="requests-container">
              {pendingRequests.map((request, index) => (
                <div key={index} className="request-card pending">
                  <div className="request-header">
                    <img src={request.photo} alt={request.name} className="viewer-photo" />
                    <div className="viewer-info">
                      <h3 className="viewer-name">{request.name}</h3>
                      <p className="viewer-email">{request.email}</p>
                    </div>
                    <div className="request-time">
                      {request.scannedAt && (
                        <small>
                          {new Date(request.scannedAt.toDate?.() || request.scannedAt).toLocaleString('id-ID')}
                        </small>
                      )}
                    </div>
                  </div>

                  {/* DEVICE INFO */}
                  {request.deviceInfo && (
                    <div className="device-info-section">
                      <div className="device-badge">
                        <span className="badge-icon">📱</span>
                        <div className="device-details">
                          <p className="device-type"><strong>{request.deviceInfo.deviceType}</strong></p>
                          <p className="device-specs">
                            {request.deviceInfo.deviceOS} • {request.deviceInfo.deviceBrowser}
                          </p>
                          <p className="device-model">{request.deviceInfo.deviceModel}</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* ACTION BUTTONS */}
                  <div className="request-actions">
                    <button
                      onClick={() => handleAccept(request.uid, index)}
                      disabled={loading}
                      className="btn-accept"
                    >
                      ✅ Accept
                    </button>
                    <button
                      onClick={() => handleReject(request.uid, index)}
                      disabled={loading}
                      className="btn-reject"
                    >
                      ❌ Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* SECTION 3: APPROVED VIEWERS */}
        {approvedViewers.length > 0 && (
          <section className="qr-section">
            <div className="section-header">
              <h2>✅ Approved Viewers ({approvedViewers.length})</h2>
              <p className="section-description">People who have access to your group</p>
            </div>

            <div className="approved-container">
              {approvedViewers.map((viewer, index) => (
                <div key={index} className="approved-card">
                  <img src={viewer.photo} alt={viewer.name} className="viewer-photo" />
                  <div className="viewer-info">
                    <h4>{viewer.name}</h4>
                    <p>{viewer.email}</p>
                    <small>✅ Approved</small>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

      </main>
    </div>
  );
}

/**
 * FEATURES:
 * 
 * 1. QR Code Display
 *    - Toggle show/hide
 *    - Group ID displayed
 *    - Share instructions
 * 
 * 2. Pending Requests Management
 *    - List semua viewer yang scan QR
 *    - Show device info (type, OS, browser, model)
 *    - Accept/Reject buttons
 *    - Real-time updates
 * 
 * 3. Approved Viewers List
 *    - Show viewers yang sudah approved
 *    - Read-only list
 * 
 * 4. Real-Time Listener
 *    - Auto-update saat ada changes
 *    - No refresh needed
 * 
 * 5. Error Handling
 *    - Show error messages
 *    - Loading states
 */