import React, { useState, useEffect } from "react";
import { signInWithPopup, onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { auth, googleProvider, db } from "./firebase";
import PairingModal from "./PairingModal";
import WaitingApproval from "./WaitingApproval"; // ← NEW IMPORT
import "./Login.css";

export default function Login({ setUser }) {
  const [userRole, setUserRole] = useState("");
  const [loading, setLoading] = useState(false);
  
  // Existing states
  const [showPairingModal, setShowPairingModal] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [checkingGroup, setCheckingGroup] = useState(true);
  
  // ← NEW STATES untuk approval system
  const [showWaitingApproval, setShowWaitingApproval] = useState(false);
  const [showRejected, setShowRejected] = useState(false);
  const [rejectionReason, setRejectionReason] = useState("");

  // ← UPDATED: Check login state & approval status
  useEffect(() => {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);

        try {
          const userRef = doc(db, "users", user.uid);
          const userDoc = await getDoc(userRef);

          if (userDoc.exists()) {
            const userData = userDoc.data();
            const approvalStatus = userData.approvalStatus; // null, "pending", "approved", "rejected"

            console.log("User approval status:", approvalStatus);

            // ← NEW: Check approvalStatus
            if (approvalStatus === "approved") {
              // ✅ User approved → proceed to Menu
              console.log("User approved! Proceed to Menu");
              
              setUser({
                uid: user.uid,
                name: userData.name || user.displayName,
                email: user.email,
                photo: userData.photo || user.photoURL,
                groupId: userData.groupId,
                role: userData.role,
              });
              setCheckingGroup(false);
              
            } else if (approvalStatus === "pending") {
              // ⏳ User pending → show waiting screen
              console.log("User pending approval");
              
              setShowWaitingApproval(true);
              setCurrentUser({
                uid: user.uid,
                name: user.displayName,
                email: user.email,
                photo: user.photoURL,
                groupId: userData.groupId,
                approvalStatus: "pending",
              });
              setCheckingGroup(false);
              
            } else if (approvalStatus === "rejected") {
              // ❌ User rejected → show error
              console.log("User approval rejected");
              
              setShowRejected(true);
              setRejectionReason("Owner rejected your request. Please try again or contact them.");
              setCheckingGroup(false);
              
            } else {
              // null/undefined → first time user
              console.log("First time user, show pairing");
              
              // Check if already has groupId
              if (userData.groupId) {
                // Has groupId but no approval status yet - shouldn't happen but handle it
                setShowPairingModal(true);
              } else {
                // No groupId → show pairing modal
                setShowPairingModal(true);
              }
              
              setCurrentUser({
                uid: user.uid,
                name: user.displayName,
                email: user.email,
                photo: user.photoURL,
              });
              setCheckingGroup(false);
            }
          } else {
            // User document tidak ada → create
            console.log("Creating new user document");
            
            await setDoc(userRef, {
              uid: user.uid,
              name: user.displayName,
              email: user.email,
              photo: user.photoURL,
              groupId: null,
              role: null,
              approvalStatus: null, // ← ADD THIS
              createdAt: new Date(),
              updatedAt: new Date(),
            });

            setShowPairingModal(true);
            setCurrentUser({
              uid: user.uid,
              name: user.displayName,
              email: user.email,
              photo: user.photoURL,
            });
            setCheckingGroup(false);
          }
        } catch (error) {
          console.error("Error checking user status:", error);
          alert("❌ Error checking pairing status!");
          setCheckingGroup(false);
        }
      } else {
        setCheckingGroup(false);
      }
    });
  }, [setUser]);

  // ← NEW: Handle approval approved
  const handleApprovalApproved = async () => {
    console.log("✅ Approval approved! Fetching latest data...");
    
    try {
      const userRef = doc(db, "users", currentUser.uid);
      const userDoc = await getDoc(userRef);
      
      if (userDoc.exists()) {
        const userData = userDoc.data();
        
        setUser({
          uid: currentUser.uid,
          name: userData.name,
          email: currentUser.email,
          photo: userData.photo,
          groupId: userData.groupId,
          role: userData.role,
        });
      }
    } catch (error) {
      console.error("Error fetching approved data:", error);
      alert("Error! Please refresh the page.");
    }
    
    setShowWaitingApproval(false);
  };

  // ← NEW: Handle approval rejected
  const handleApprovalRejected = () => {
    console.log("❌ Approval rejected");
    setShowWaitingApproval(false);
    setShowRejected(true);
    setRejectionReason("Owner rejected your request. You can try scanning a different QR code.");
  };

  // ← NEW: Handle retry pairing
  const handleRetryPairing = () => {
    console.log("Retrying pairing...");
    setShowRejected(false);
    setShowPairingModal(true);
  };

  const handleGroupCreated = (groupId) => {
    console.log("✅ Group created:", groupId);
    setShowPairingModal(false);
  };

  const handleGroupJoined = async (groupId) => {
    console.log("✅ Group joined:", groupId);

    try {
      const userRef = doc(db, "users", currentUser.uid);
      const userDoc = await getDoc(userRef);

      if (userDoc.exists()) {
        const userData = userDoc.data();

        console.log("User data updated:", userData);

        setUser({
          uid: currentUser.uid,
          name: userData.name,
          email: currentUser.email,
          photo: userData.photo,
          groupId: userData.groupId,
          role: userData.role,
        });
      }
    } catch (error) {
      console.error("❌ Error fetching updated user data:", error);
      alert("Error updating user data!");
    }

    setShowPairingModal(false);
  };

  const handleGoogleLogin = async () => {
    try {
      setLoading(true);
      const result = await signInWithPopup(auth, googleProvider);
      
      console.log("User logged in:", result.user.uid);
      
      if (userRole) {
        localStorage.setItem("userRole", userRole);
      }
    } catch (error) {
      console.error("❌ Login failed:", error);
      alert("Login gagal! Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  // ← NEW: Show WaitingApproval jika pending
  if (showWaitingApproval && currentUser) {
    return (
      <WaitingApproval
        user={{
          uid: currentUser.uid,
          name: currentUser.name,
          email: currentUser.email,
          photo: currentUser.photo,
        }}
        onApproved={handleApprovalApproved}
        onRejected={handleApprovalRejected}
      />
    );
  }

  // ← NEW: Show rejection screen jika rejected
  if (showRejected) {
    return (
      <div className="login-page">
        <div className="login-wrapper">
          <div className="login-form-section">
            <div className="login-card">
              <div className="login-header">
                <h2>❌ Access Denied</h2>
                <p>Request rejected by owner</p>
              </div>
              
              <div style={{ padding: "20px", textAlign: "center" }}>
                <p style={{ color: "#8B6F9E", marginBottom: "20px" }}>
                  {rejectionReason}
                </p>
              </div>
              
              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                <button
                  onClick={handleRetryPairing}
                  className="google-login-btn"
                  style={{
                    background: "linear-gradient(135deg, #E74C3C, #C0392B)",
                  }}
                >
                  🔄 Try Again (Scan Different QR)
                </button>
                
                <button
                  onClick={() => window.location.reload()}
                  className="google-login-btn"
                  style={{
                    background: "linear-gradient(135deg, #95A5A6, #7F8C8D)",
                  }}
                >
                  🔄 Refresh Page
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show PairingModal jika user belum punya group/approval
  if (showPairingModal && currentUser) {
    return (
      <PairingModal
        user={{
          uid: currentUser.uid,
          name: currentUser.name,
          email: currentUser.email,
          photo: currentUser.photo,
        }}
        onGroupCreated={handleGroupCreated}
        onGroupJoined={handleGroupJoined}
      />
    );
  }

  // Show loading state saat checking
  if (checkingGroup) {
    return (
      <div className="login-page">
        <div className="login-wrapper">
          <div className="login-form-section">
            <div className="login-card">
              <div className="login-header">
                <h2>Checking pairing status... 🔄</h2>
                <p>Please wait a moment</p>
              </div>
              <div className="loading-spinner"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ← ORIGINAL LOGIN UI (if user not logged in)
  return (
    <div className="login-page">
      {/* Background Elements */}
      <div className="login-bg">
        <div className="gradient-blob blob-1"></div>
        <div className="gradient-blob blob-2"></div>
        <div className="gradient-blob blob-3"></div>
      </div>

      {/* Main Container */}
      <div className="login-wrapper">
        {/* Left Side - Branding */}
        <div className="login-brand-section">
          <div className="brand-content">
            <div className="brand-logo">
              <img src="/logo_nobg.png" alt="Infinity Love" />
            </div>
            <h1 className="brand-name">Yubul</h1>
            <p className="brand-tagline">
              Tabungan berdua bareng pacar jadi makin <span>harmonis</span> 💕
            </p>

            {/* Features */}
            <div className="features-list">
              <div className="feature-item">
                <span className="feature-icon">💰</span>
                <div>
                  <p>Kelola Tabungan</p>
                  <small>Tracking uang kalian berdua dengan mudah</small>
                </div>
              </div>
              <div className="feature-item">
                <span className="feature-icon">📊</span>
                <div>
                  <p>Lihat Statistik</p>
                  <small>Analisis pengeluaran dan pemasukan realtime</small>
                </div>
              </div>
              <div className="feature-item">
                <span className="feature-icon">💕</span>
                <div>
                  <p>Transparansi</p>
                  <small>Lihat kemana uang keluar dengan jelas</small>
                </div>
              </div>
            </div>

            {/* Decorative Quote */}
            <div className="love-quote">
              <p>"Cinta + Uang Terkelola = Hubungan Sehat"</p>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="login-form-section">
          <div className="login-card">
            {/* Header */}
            <div className="login-header">
              <h2>Selamat datang di Yubul! 🎉</h2>
              <p>Mulai kelola keuangan berdua sekarang</p>
            </div>

            {/* Role Selection */}
            <div className="role-selection">
              <label className="role-label">Kamu siapa di hubungan ini? 👀</label>
              <div className="role-buttons">
                <button
                  className={`role-btn ${userRole === "cowo" ? "active" : ""}`}
                  onClick={() => setUserRole("cowo")}
                  disabled={loading}
                >
                  <span className="role-emoji">👨‍🦰</span>
                  <span>Cowo</span>
                </button>
                <button
                  className={`role-btn ${userRole === "cewe" ? "active" : ""}`}
                  onClick={() => setUserRole("cewe")}
                  disabled={loading}
                >
                  <span className="role-emoji">👩‍🦱</span>
                  <span>Cewe</span>
                </button>
              </div>
            </div>

            {/* Selected Status */}
            {userRole && (
              <div className="role-status">
                <p>
                  ✨ Mantap! Kamu pilih jadi{" "}
                  <strong>{userRole === "cowo" ? "Cowok" : "Cewe"}</strong> 💪
                </p>
              </div>
            )}

            {/* Google Login Button */}
            <button
              onClick={handleGoogleLogin}
              disabled={!userRole || loading}
              className="google-login-btn"
            >
              {loading ? (
                <>
                  <span className="spinner"></span>
                  Sedang login...
                </>
              ) : (
                <>
                  <img
                    src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                    alt="Google"
                  />
                  Login dengan Google
                </>
              )}
            </button>

            {/* Divider */}
            <div className="divider">
              <span>atau</span>
            </div>

            {/* Terms & Security */}
            <div className="login-footer">
              <p className="security-note">
                🔒 Data kamu aman dan terenkripsi dengan Firebase
              </p>
              <p className="terms-note">
                Dengan login, kamu setuju dengan Terms & Conditions kami
              </p>
            </div>
          </div>

          {/* Floating Elements */}
          <div className="floating-elements">
            <div className="float-emoji emoji-1">💕</div>
            <div className="float-emoji emoji-2">✨</div>
            <div className="float-emoji emoji-3">💑</div>
            <div className="float-emoji emoji-4">💰</div>
          </div>
        </div>
      </div>

      {/* Mobile Responsive Note */}
      <div className="mobile-only">
        <div className="login-card-mobile">
          <div className="login-header">
            <div className="brand-logo">
              <img src="/logo_nobg.png" alt="Infinity Love" />
            </div>
            <h2>Yubul</h2>
            <p>Tabungan Berdua Jadi Harmonis</p>
          </div>

          <div className="role-selection">
            <label className="role-label">Kamu siapa? 👀</label>
            <div className="role-buttons">
              <button
                className={`role-btn ${userRole === "cowo" ? "active" : ""}`}
                onClick={() => setUserRole("cowo")}
                disabled={loading}
              >
                <span>👨‍🦰 Cowo</span>
              </button>
              <button
                className={`role-btn ${userRole === "cewe" ? "active" : ""}`}
                onClick={() => setUserRole("cewe")}
                disabled={loading}
              >
                <span>👩‍🦱 Cewe</span>
              </button>
            </div>
          </div>

          {userRole && (
            <div className="role-status">
              <p>
                ✨ Mantap! Kamu{" "}
                <strong>{userRole === "cowo" ? "Cowok" : "Cewe"}</strong> 💪
              </p>
            </div>
          )}

          <button
            onClick={handleGoogleLogin}
            disabled={!userRole || loading}
            className="google-login-btn"
          >
            {loading ? "Sedang login..." : "Login dengan Google"}
          </button>

          <p className="security-note">🔒 Data aman dengan Firebase</p>
        </div>
      </div>
    </div>
  );
}

/**
 * CHANGES FOR STEP 3 (PHASE 2B-2):
 * 
 * 1. NEW IMPORT:
 *    - WaitingApproval from "./WaitingApproval"
 * 
 * 2. NEW STATES:
 *    - showWaitingApproval: Show when approvalStatus = "pending"
 *    - showRejected: Show when approvalStatus = "rejected"
 *    - rejectionReason: Error message
 * 
 * 3. UPDATED useEffect:
 *    - Now checks approvalStatus (not just groupId)
 *    - Routes to different screens based on status:
 *      * "approved" → setUser → go to Menu
 *      * "pending" → show WaitingApproval screen
 *      * "rejected" → show error screen
 *      * null → show PairingModal (first-time)
 * 
 * 4. NEW HANDLERS:
 *    - handleApprovalApproved(): Called from WaitingApproval when approved
 *    - handleApprovalRejected(): Called from WaitingApproval when rejected
 *    - handleRetryPairing(): Show pairing modal again
 * 
 * 5. NEW EARLY RETURNS:
 *    - If showWaitingApproval → show WaitingApproval component
 *    - If showRejected → show error/rejection screen
 *    - If showPairingModal → show PairingModal (existing)
 *    - If checkingGroup → show loading (existing)
 *    - Else → show original login UI
 */