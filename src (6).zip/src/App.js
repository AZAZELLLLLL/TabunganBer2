import React, { useState, useEffect } from "react";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "./firebase";
import Splash from "./Splash";
import Login from "./login";
import Menu from "./Menu";
import Dashboard from "./Dashboard";
import Expenses from "./Expenses";
import Savings from "./Savings";
import History from "./History";
import Stats from "./Stats";
import QRGenerator from "./QRGenerator"; // ← NEW IMPORT
import PairingVerification from "./PairingVerification";
import "./App.css";

/**
 * APP.JS - UPDATED FOR QRGENERATOR
 * 
 * Changes:
 * 1. Import QRGenerator component
 * 2. Add routing untuk QRGenerator page (owner only)
 * 3. Security check: only show QRGenerator jika user.isOwner === true
 */

function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState("menu");
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Handle splash screen
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  // Check if user is logged in
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        // ← Let Login.js handle setUser
      } else {
        setUser(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const handleNavigate = (page) => {
    if (page === currentPage) return;

    setIsTransitioning(true);

    setTimeout(() => {
      setCurrentPage(page);
      setIsTransitioning(false);
    }, 300);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setCurrentPage("menu");
      localStorage.removeItem("userRole");
    } catch (error) {
      console.error("Logout error:", error);
      alert("Gagal logout!");
    }
  };

  const handleSplashComplete = () => {
    setShowSplash(false);
  };

  // Loading state
  if (loading) {
    return <div className="app loading">Loading...</div>;
  }

  // Splash screen
  if (showSplash) {
    return (
      <div className="app">
        <Splash onComplete={handleSplashComplete} />
      </div>
    );
  }

  // Not logged in - show login
  if (!user) {
    return (
      <div className="app">
        <Login setUser={setUser} />
      </div>
    );
  }

  // Logged in - show pages with transitions
  return (
    <div className="app">
      <div className={`page-container ${isTransitioning ? "transitioning" : ""}`}>
        {currentPage === "menu" && (
          <Menu user={user} onNavigate={handleNavigate} onLogout={handleLogout} />
        )}

        {currentPage === "dashboard" && (
          <Dashboard user={user} onLogout={handleLogout} onNavigate={handleNavigate} />
        )}

        {currentPage === "expenses" && (
          <Expenses user={user} onNavigate={handleNavigate} />
        )}

        {currentPage === "savings" && (
          <Savings user={user} onNavigate={handleNavigate} />
        )}

        {currentPage === "income" && (
          <History user={user} onNavigate={handleNavigate} />
        )}

        {currentPage === "stats" && (
          <Stats user={user} onNavigate={handleNavigate} />
        )}

        {/* ← NEW: QRGenerator routing (Owner only!) */}
        {currentPage === "qr-generator" && user.isOwner && (
          <QRGenerator
            user={user}
            onBack={() => setCurrentPage("menu")}
          />
        )}

        {/* Keep for reference */}
        {currentPage === "pairing" && (
          <PairingVerification
            user={user}
            onBack={() => setCurrentPage("menu")}
          />
        )}
      </div>
    </div>
  );
}

export default App;

/**
 * KEY CHANGES:
 * 
 * 1. Added QRGenerator import
 *    └─ New component untuk owner manage QR & approvals
 * 
 * 2. Added QRGenerator routing
 *    └─ if currentPage === "qr-generator" && user.isOwner
 *    └─ Show QRGenerator component
 * 
 * 3. Security check
 *    └─ Only show QRGenerator jika user.isOwner === true
 *    └─ Prevent viewer access to owner features
 * 
 * 4. Kept PairingVerification
 *    └─ Backup/reference component
 *    └─ Can be removed later jika tidak perlu
 */