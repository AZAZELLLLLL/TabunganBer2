import React from "react";
import "./Menu.css";

/**
 * MENU.JS - UPDATED VERSION
 * 
 * Changes:
 * 1. Change user.role === "owner" to user.isOwner (boolean flag)
 * 2. Change display from "👨 Cowo" / "👩 Cewe" to "👑 Owner" / "👤 Viewer"
 * 3. Change menu item from "Verifikasi Pairing" to "Generate QR"
 * 4. Change menu item id from "pairing" to "qr-generator"
 * 5. Only show Generate QR menu for owner (user.isOwner === true)
 */

export default function Menu({ user, onNavigate, onLogout }) {
  // Base menu items (always visible for both owner & viewer)
  const baseMenuItems = [
    {
      id: "dashboard",
      emoji: "🏠",
      label: "Dashboard",
      description: "Lihat ringkasan keuangan",
      color: "dashboard",
    },
    {
      id: "savings",
      emoji: "💰",
      label: "Tabungan",
      description: "Kelola tabungan berdua",
      color: "savings",
    },
    {
      id: "expenses",
      emoji: "💸",
      label: "Pengeluaran",
      description: "Catat pengeluaran harian",
      color: "expenses",
    },
    {
      id: "income",
      emoji: "💵",
      label: "Pemasukan",
      description: "Catat pemasukan bulanan",
      color: "income",
    },
    {
      id: "stats",
      emoji: "📊",
      label: "Statistik",
      description: "Analisis keuangan real-time",
      color: "stats",
    },
  ];

  // Owner-only menu items
  const ownerMenuItems = [
    {
      id: "qr-generator", // ← Changed from "pairing"
      emoji: "🔐",
      label: "Generate QR", // ← Changed from "Verifikasi Pairing"
      description: "Kelola QR dan verifikasi partner",
      color: "pairing",
    },
  ];

  // Combine menu items based on user role
  // ← Changed from user.role === "owner" to user.isOwner
  const menuItems = user.isOwner
    ? [...baseMenuItems, ...ownerMenuItems]
    : baseMenuItems;

  return (
    <div className="menu-page">
      {/* Header */}
      <header className="menu-header">
        <div className="menu-header-content">
          <div className="menu-logo">
            <h1>💕 Infinity Love</h1>
            <p>Kelola Keuangan Berdua</p>
          </div>
          <div className="menu-user">
            <img src={user.photo} alt={user.name} />
            <div>
              <p>{user.name}</p>
              {/* ← Changed from user.role display to user.isOwner display */}
              <small>{user.isOwner ? "👑 Owner" : "👤 Viewer"}</small>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="menu-content">
        <div className="menu-grid">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`menu-card menu-card-${item.color}`}
            >
              <div className="menu-card-emoji">{item.emoji}</div>
              <div className="menu-card-text">
                <h2>{item.label}</h2>
                <p>{item.description}</p>
              </div>
              <div className="menu-card-arrow">→</div>
            </button>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="menu-footer">
        <button onClick={onLogout} className="menu-logout-btn">
          🚪 Logout
        </button>
      </footer>
    </div>
  );
}

/**
 * KEY CHANGES:
 * 
 * 1. CHANGED: Role check
 *    FROM: user.role === "owner"
 *    TO: user.isOwner (boolean flag)
 * 
 * 2. CHANGED: User role display
 *    FROM: user.role === "cowo" ? "👨 Cowo" : "👩 Cewe"
 *    TO: user.isOwner ? "👑 Owner" : "👤 Viewer"
 * 
 * 3. CHANGED: Menu item label
 *    FROM: "Verifikasi Pairing"
 *    TO: "Generate QR"
 * 
 * 4. CHANGED: Menu item id
 *    FROM: "pairing"
 *    TO: "qr-generator"
 * 
 * 5. RESULT:
 *    Owner sees 6 menu items (including Generate QR)
 *    Viewer sees 5 menu items (without Generate QR)
 */