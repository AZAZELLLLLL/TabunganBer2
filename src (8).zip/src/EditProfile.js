import React, { useState, useRef } from "react";
import { doc, updateDoc, getStorage, ref, uploadBytes, getDownloadURL } from "firebase/firestore";
import { db } from "./firebase";
import "./EditProfile.css";

/**
 * EDIT PROFILE - COMPLETE VERSION
 * 
 * ✅ Features:
 * 1. Avatar upload dari device
 * 2. Edit nama (sync ke semua halaman)
 * 3. Edit gender (cowo/cewe)
 * 4. Save to Firestore + Firebase Storage
 * 5. Real-time update semua halaman
 * 
 * 📍 Data tersimpan di:
 * - Firestore: users/{uid}
 * - Storage: avatars/{uid}_{timestamp}.jpg
 * 
 * 🔄 Sync otomatis ke:
 * - Dashboard (nama & photo)
 * - Income (nama & photo)
 * - Expenses (nama & photo)
 * - Savings detail (nama & photo)
 * - Menu header (nama & photo)
 * - QR Generator (nama & photo di pending)
 */

export default function EditProfile({ user, onClose, onUpdate }) {
  const [name, setName] = useState(user.name || "");
  const [gender, setGender] = useState(user.gender || "cowo");
  const [avatarFile, setAvatarFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(user.photo || "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef(null);

  // ✅ Handle avatar selection
  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith("image/")) {
      setError("❌ Hanya file gambar yang diperbolehkan!");
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError("❌ Ukuran foto maksimal 5MB!");
      return;
    }

    setAvatarFile(file);
    setError(null);

    // Create preview URL
    const reader = new FileReader();
    reader.onload = (event) => {
      setPreviewUrl(event.target.result);
    };
    reader.readAsDataURL(file);

    console.log("✅ Avatar file selected:", file.name);
  };

  // ✅ Upload avatar to Firebase Storage
  const uploadAvatarToStorage = async () => {
    if (!avatarFile) {
      return user.photo; // Return existing if no new file
    }

    try {
      setUploadProgress(10);

      const storage = getStorage();
      const fileName = `avatars/${user.uid}_${Date.now()}.jpg`;
      const storageRef = ref(storage, fileName);

      console.log("Uploading avatar to:", fileName);

      // Upload file
      await uploadBytes(storageRef, avatarFile);
      setUploadProgress(50);

      // Get download URL
      const downloadUrl = await getDownloadURL(storageRef);
      setUploadProgress(100);

      console.log("✅ Avatar uploaded successfully:", downloadUrl);
      return downloadUrl;
    } catch (error) {
      console.error("❌ Error uploading avatar:", error);
      throw new Error("Gagal upload foto: " + error.message);
    }
  };

  // ✅ Save profile to Firestore
  const handleSaveProfile = async () => {
    // Validation
    if (!name.trim()) {
      setError("❌ Nama tidak boleh kosong!");
      return;
    }

    if (name.trim().length < 3) {
      setError("❌ Nama minimal 3 karakter!");
      return;
    }

    setLoading(true);
    setError(null);
    setUploadProgress(0);

    try {
      console.log("🔄 Saving profile...");

      // Upload avatar if changed
      let photoUrl = user.photo;
      if (avatarFile) {
        console.log("📤 Uploading avatar...");
        photoUrl = await uploadAvatarToStorage();
      }

      // Update Firestore
      console.log("💾 Updating Firestore...");
      const userRef = doc(db, "users", user.uid);

      await updateDoc(userRef, {
        name: name.trim(),
        photo: photoUrl,
        gender: gender,
        updatedAt: new Date(),
      });

      console.log("✅ Profile saved successfully!");

      // Notify parent
      const updatedUserData = {
        ...user,
        name: name.trim(),
        photo: photoUrl,
        gender: gender,
      };

      if (onUpdate) {
        onUpdate(updatedUserData);
      }

      // Success message
      alert("✅ Profil berhasil diperbarui!\n\nPerubahan akan muncul di semua halaman.");

      // Close modal
      setTimeout(() => {
        if (onClose) {
          onClose();
        }
      }, 500);
    } catch (err) {
      console.error("❌ Error saving profile:", err);
      setError("❌ Gagal menyimpan: " + err.message);
    } finally {
      setLoading(false);
      setUploadProgress(0);
    }
  };

  // ✅ Handle cancel
  const handleCancel = () => {
    setName(user.name || "");
    setGender(user.gender || "cowo");
    setAvatarFile(null);
    setPreviewUrl(user.photo || "");
    setError(null);
    setUploadProgress(0);

    if (onClose) {
      onClose();
    }
  };

  // Check if data changed
  const hasChanges =
    name.trim() !== user.name ||
    gender !== user.gender ||
    avatarFile !== null;

  return (
    <div className="edit-profile-overlay">
      <div className="edit-profile-modal">
        {/* Header */}
        <div className="edit-profile-header">
          <h2>✏️ Edit Profil</h2>
          <button
            onClick={handleCancel}
            disabled={loading}
            className="close-btn"
            title="Close"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="edit-profile-content">
          {/* Error Message */}
          {error && (
            <div className="error-message">
              <p>{error}</p>
            </div>
          )}

          {/* Avatar Section */}
          <div className="avatar-section">
            <div className="avatar-container">
              <img
                src={previewUrl}
                alt="Profile Avatar"
                className="avatar-preview"
              />
              {avatarFile && (
                <div className="avatar-changed-badge">
                  ✓ Changed
                </div>
              )}
            </div>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleAvatarChange}
              accept="image/*"
              style={{ display: "none" }}
              disabled={loading}
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={loading}
              className="btn-upload-avatar"
            >
              📷 Ganti Foto Profil
            </button>

            <small className="avatar-info">
              Format: JPG, PNG, GIF (Maks 5MB)
            </small>

            {uploadProgress > 0 && uploadProgress < 100 && (
              <div className="progress-bar">
                <div
                  className="progress-fill"
                  style={{ width: `${uploadProgress}%` }}
                ></div>
              </div>
            )}
          </div>

          {/* Divider */}
          <div className="divider"></div>

          {/* Name Section */}
          <div className="form-group">
            <label htmlFor="fullname">📝 Nama Lengkap</label>
            <input
              id="fullname"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masukkan nama lengkap"
              disabled={loading}
              className="form-input"
              maxLength="50"
            />
            <small className="form-hint">
              Nama ini akan ditampilkan di semua halaman
            </small>
          </div>

          {/* Gender Section */}
          <div className="form-group">
            <label>👫 Gender</label>
            <div className="gender-options">
              <button
                type="button"
                onClick={() => setGender("cowo")}
                disabled={loading}
                className={`gender-btn ${gender === "cowo" ? "active" : ""}`}
              >
                <span className="emoji">👨</span>
                <span className="label">Cowo</span>
              </button>
              <button
                type="button"
                onClick={() => setGender("cewe")}
                disabled={loading}
                className={`gender-btn ${gender === "cewe" ? "active" : ""}`}
              >
                <span className="emoji">👩</span>
                <span className="label">Cewe</span>
              </button>
            </div>
          </div>

          {/* Info Box */}
          <div className="info-box">
            <p>
              💡 <strong>Catatan:</strong> Perubahan nama dan foto akan langsung
              terlihat di semua halaman tanpa perlu refresh.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="edit-profile-footer">
          <button
            onClick={handleCancel}
            disabled={loading}
            className="btn-cancel"
          >
            ❌ Batal
          </button>
          <button
            onClick={handleSaveProfile}
            disabled={loading || !hasChanges || !name.trim()}
            className="btn-save"
          >
            {loading ? "⏳ Menyimpan..." : "✅ Simpan Perubahan"}
          </button>
        </div>
      </div>
    </div>
  );
}