import React, { useState } from "react";
import EditProfile from "./EditProfile";
import "./Menu.css";

/**
 * MENU.JS - WITH EDIT PROFILE FEATURE
 * 
 * Features:
 * 1. ✅ Menu items (Dashboard, Tabungan, etc)
 * 2. ✅ Owner/Viewer role indicator
 * 3. ✅ Edit Profile button (✏️)
 * 4. ✅ EditProfile modal
 * 5. ✅ Real-time update user data
 */

export default function Menu({ user, onNavigate, onLogout }) {
  // Edit Profile modal state
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [currentUser, setCurrentUser] = useState(user);

  // Base menu items (visible for both owner & viewer)
  const baseMenuItems = [
    {
      id: "dashboard",
      emoji: "🏠",
      label: "Dashboard",
      description: "Lihat ringkasan keuangan",
      color: "dashboard",
    },
    {
      id: "savings",
      emoji: "💰",
      label: "Tabungan",
      description: "Kelola tabungan berdua",
      color: "savings",
    },
    {
      id: "expenses",
      emoji: "💸",
      label: "Pengeluaran",
      description: "Catat pengeluaran harian",
      color: "expenses",
    },
    {
      id: "income",
      emoji: "💵",
      label: "Pemasukan",
      description: "Catat pemasukan bulanan",
      color: "income",
    },
    {
      id: "stats",
      emoji: "📊",
      label: "Statistik",
      description: "Analisis keuangan real-time",
      color: "stats",
    },
  ];

  // Owner-only menu items
  const ownerMenuItems = [
    {
      id: "qr-generator",
      emoji: "🔐",
      label: "Generate QR",
      description: "Kelola QR dan verifikasi partner",
      color: "pairing",
    },
  ];

  // Combine menu items
  const menuItems = currentUser.isOwner
    ? [...baseMenuItems, ...ownerMenuItems]
    : baseMenuItems;

  // Handle edit profile save
  const handleEditProfileSave = (updatedUser) => {
    setCurrentUser(updatedUser);
    console.log("✅ User profile updated:", updatedUser);
  };

  return (
    <div className="menu-page">
      {/* Header */}
      <header className="menu-header">
        <div className="menu-header-content">
          <div className="menu-logo">
            <h1>Tabungan</h1>
            <p>Kelola Keuangan Berdua</p>
          </div>
          
          {/* User Info with Edit Button */}
          <div className="menu-user-section">
            <div className="menu-user">
              <img src={currentUser.photo} alt={currentUser.name} />
              <div>
                <p>{currentUser.name}</p>
                <small>
                  {currentUser.isOwner ? "👑 Owner" : "👤 Viewer"}
                </small>
              </div>
            </div>
            {/* Edit Profile Button */}
            <button
              onClick={() => setShowEditProfile(true)}
              className="btn-edit-profile"
              title="Edit profil"
            >
              ✏️
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="menu-content">
        <div className="menu-grid">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`menu-card menu-card-${item.color}`}
            >
              <div className="menu-card-emoji">{item.emoji}</div>
              <div className="menu-card-text">
                <h2>{item.label}</h2>
                <p>{item.description}</p>
              </div>
              <div className="menu-card-arrow">→</div>
            </button>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="menu-footer">
        <button onClick={onLogout} className="menu-logout-btn">
          🚪 Logout
        </button>
      </footer>

      {/* Edit Profile Modal */}
      {showEditProfile && (
        <EditProfile
          user={currentUser}
          onClose={() => setShowEditProfile(false)}
          onUpdate={handleEditProfileSave}
        />
      )}
    </div>
  );
}

/**
 * CHANGES FROM PREVIOUS VERSION:
 * 
 * 1. Import EditProfile component
 * 2. Add state: showEditProfile, currentUser
 * 3. Wrap user info in menu-user-section
 * 4. Add ✏️ button with onClick handler
 * 5. Add EditProfile modal at bottom
 * 6. Handle profile updates with handleEditProfileSave
 * 
 * KEY POINTS:
 * - currentUser state updates when profile saved
 * - Menu header shows updated name & photo immediately
 * - All other pages auto-update via real-time listeners
 * - No need to pass data to parent App component
 * - Modal is self-contained and manages its own state
 */