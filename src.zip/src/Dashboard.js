import React, { useState, useEffect } from "react";
import {
  collection,
  addDoc,
  query,
  where,
  onSnapshot,
} from "firebase/firestore";
import { db } from "./firebase";
import "./Dashboard.css";

export default function Dashboard({ user, onLogout, onNavigate }) {
  const [savings, setSavings] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [income, setIncome] = useState([]);
  const [cowoAmount, setCowoAmount] = useState("");
  const [ceweAmount, setCeweAmount] = useState("");
  const [loading, setLoading] = useState(false);

  // Fetch data real-time
  useEffect(() => {
    const groupId = user.groupId || "default";

    // Fetch Savings
    const savingsQuery = query(
      collection(db, "savings"),
      where("groupId", "==", groupId)
    );

    const unsubscribeSavings = onSnapshot(savingsQuery, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setSavings(data.sort((a, b) => b.date - a.date));
    });

    // Fetch Expenses
    const expensesQuery = query(
      collection(db, "expenses"),
      where("groupId", "==", groupId)
    );

    const unsubscribeExpenses = onSnapshot(expensesQuery, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setExpenses(data);
    });

    // Fetch Income
    const incomeQuery = query(
      collection(db, "income"),
      where("groupId", "==", groupId)
    );

    const unsubscribeIncome = onSnapshot(incomeQuery, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setIncome(data);
    });

    return () => {
      unsubscribeSavings();
      unsubscribeExpenses();
      unsubscribeIncome();
    };
  }, [user.groupId]);

  const handleAddSavings = async (e, role) => {
    e.preventDefault();
    const amount = role === "cowo" ? cowoAmount : ceweAmount;

    if (!amount || parseFloat(amount) <= 0) {
      alert("Isi jumlah uang yang valid!");
      return;
    }

    setLoading(true);
    try {
      await addDoc(collection(db, "savings"), {
        groupId: user.groupId || "default",
        role,
        userName: user.name,
        userPhoto: user.photo,
        userId: user.uid,
        amount: parseFloat(amount),
        date: new Date(),
      });

      if (role === "cowo") {
        setCowoAmount("");
      } else {
        setCeweAmount("");
      }
      alert("Tabungan berhasil ditambahkan! 💕");
    } catch (error) {
      console.error("Error adding savings:", error);
      alert("Gagal menambah tabungan!");
    } finally {
      setLoading(false);
    }
  };

  const handleAddBothSavings = async () => {
    if (!cowoAmount || !ceweAmount) {
      alert("Isi jumlah tabungan kedua-duanya!");
      return;
    }

    if (parseFloat(cowoAmount) <= 0 || parseFloat(ceweAmount) <= 0) {
      alert("Jumlah harus lebih dari 0!");
      return;
    }

    setLoading(true);
    try {
      // Tambah Cowo
      await addDoc(collection(db, "savings"), {
        groupId: user.groupId || "default",
        role: "cowo",
        userName: user.name,
        userPhoto: user.photo,
        userId: user.uid,
        amount: parseFloat(cowoAmount),
        date: new Date(),
      });

      // Tambah Cewe
      await addDoc(collection(db, "savings"), {
        groupId: user.groupId || "default",
        role: "cewe",
        userName: user.name,
        userPhoto: user.photo,
        userId: user.uid,
        amount: parseFloat(ceweAmount),
        date: new Date(),
      });

      setCowoAmount("");
      setCeweAmount("");
      alert("Tabungan keduanya berhasil ditambahkan! 💕💕");
    } catch (error) {
      console.error("Error adding savings:", error);
      alert("Gagal menambah tabungan!");
    } finally {
      setLoading(false);
    }
  };

  // Calculate totals
  const totalSavings = savings.reduce((sum, s) => sum + (s.amount || 0), 0);
  const cowoSavings = savings
    .filter((s) => s.role === "cowo")
    .reduce((sum, s) => sum + (s.amount || 0), 0);
  const ceweSavings = savings
    .filter((s) => s.role === "cewe")
    .reduce((sum, s) => sum + (s.amount || 0), 0);

  // Current month totals
  const now = new Date();
  const monthStart = new Date(
    now.getFullYear(),
    now.getMonth(),
    1
  );
  const monthEnd = new Date(
    now.getFullYear(),
    now.getMonth() + 1,
    0
  );

  const currentMonthExpenses = expenses
    .filter((e) => {
      const eDate = e.date?.toDate ? e.date.toDate() : new Date(e.date);
      return eDate >= monthStart && eDate <= monthEnd;
    })
    .reduce((sum, e) => sum + (e.amount || 0), 0);

  const currentMonthIncome = income
    .filter((i) => {
      const iDate = i.date?.toDate ? i.date.toDate() : new Date(i.date);
      return iDate >= monthStart && iDate <= monthEnd;
    })
    .reduce((sum, i) => sum + (i.amount || 0), 0);

  const monthlyBalance = currentMonthIncome - currentMonthExpenses;

  return (
    <div className="dashboard">
      {/* Navbar */}
      <nav className="navbar">
        <div className="nav-left">
          <h1>💕 Infinity Love</h1>
        </div>
        <div className="nav-center">
          <button
            className="nav-btn active"
            onClick={() => onNavigate("dashboard")}
          >
            🏠 Dashboard
          </button>
          <button className="nav-btn" onClick={() => onNavigate("savings")}>
            💰 Tabungan
          </button>
          <button className="nav-btn" onClick={() => onNavigate("expenses")}>
            💸 Pengeluaran
          </button>
          <button className="nav-btn" onClick={() => onNavigate("income")}>
            💵 Pemasukan
          </button>
          <button className="nav-btn" onClick={() => onNavigate("stats")}>
            📊 Statistik
          </button>
        </div>
        <div className="nav-right">
          <div className="user-info">
            <img src={user.photo} alt={user.name} />
            <div>
              <p>{user.name}</p>
              <small>{user.role === "cowo" ? "👨 Cowo" : "👩 Cewe"}</small>
            </div>
          </div>
          <button onClick={onLogout} className="logout-btn">
            Logout
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <div className="dashboard-content">
        <div className="container">
          {/* Summary Cards */}
          <div className="summary-grid">
            <div className="summary-card total">
              <p className="card-label">💑 Total Tabungan Berdua</p>
              <h2>Rp {totalSavings.toLocaleString("id-ID")}</h2>
              <p className="card-subtitle">Dari {savings.length} transaksi</p>
            </div>

            <div className="summary-card cowo">
              <p className="card-label">👨 Tabungan Cowo</p>
              <h3>Rp {cowoSavings.toLocaleString("id-ID")}</h3>
            </div>

            <div className="summary-card cewe">
              <p className="card-label">👩 Tabungan Cewe</p>
              <h3>Rp {ceweSavings.toLocaleString("id-ID")}</h3>
            </div>

            <div className="summary-card balance">
              <p className="card-label">💹 Balance Bulan Ini</p>
              <h3 className={monthlyBalance >= 0 ? "positive" : "negative"}>
                Rp {Math.abs(monthlyBalance).toLocaleString("id-ID")}
              </h3>
              <small>{monthlyBalance >= 0 ? "Surplus 📈" : "Deficit 📉"}</small>
            </div>
          </div>

          {/* Add Savings Section */}
          <div className="section add-savings-section">
            <h3>➕ Tambah Tabungan Berdua</h3>
            <div className="savings-form-grid">
              {/* Cowo Form */}
              <div className="savings-form">
                <h4>👨 Tabungan Cowo</h4>
                <form
                  onSubmit={(e) => handleAddSavings(e, "cowo")}
                  className="form"
                >
                  <input
                    type="number"
                    placeholder="Jumlah (Rp)"
                    value={cowoAmount}
                    onChange={(e) => setCowoAmount(e.target.value)}
                    disabled={loading}
                    required
                  />
                  <button type="submit" disabled={loading} className="form-btn">
                    {loading ? "Menambah..." : "Tambah Cowo"}
                  </button>
                </form>
              </div>

              {/* Cewe Form */}
              <div className="savings-form">
                <h4>👩 Tabungan Cewe</h4>
                <form
                  onSubmit={(e) => handleAddSavings(e, "cewe")}
                  className="form"
                >
                  <input
                    type="number"
                    placeholder="Jumlah (Rp)"
                    value={ceweAmount}
                    onChange={(e) => setCeweAmount(e.target.value)}
                    disabled={loading}
                    required
                  />
                  <button type="submit" disabled={loading} className="form-btn">
                    {loading ? "Menambah..." : "Tambah Cewe"}
                  </button>
                </form>
              </div>
            </div>

            {/* Tambah Keduanya Button */}
            <div className="savings-both-section">
              <button
                onClick={handleAddBothSavings}
                disabled={loading || !cowoAmount || !ceweAmount}
                className="submit-both-btn"
              >
                💕 Tambah Keduanya
              </button>
            </div>
          </div>

          {/* Recent Savings */}
          <div className="section recent-savings">
            <h3>📝 Riwayat Tabungan Terbaru</h3>
            {savings.length === 0 ? (
              <p className="empty-state">
                Belum ada tabungan. Mulai simpan uang berdua! 💕
              </p>
            ) : (
              <div className="savings-list">
                {savings.slice(0, 5).map((saving) => (
                  <div key={saving.id} className="savings-item">
                    <div className="saving-info">
                      <div className="saving-avatar">
                        {saving.role === "cowo" ? "👨" : "👩"}
                      </div>
                      <div className="saving-details">
                        <p className="saving-name">{saving.userName}</p>
                        <p className="saving-role">
                          {saving.role === "cowo" ? "Cowok" : "Cewe"}
                        </p>
                      </div>
                    </div>
                    <div className="saving-amount">
                      +Rp {saving.amount.toLocaleString("id-ID")}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}