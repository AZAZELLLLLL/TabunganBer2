import React, { useState, useEffect } from "react";
import { signInWithPopup, onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { auth, googleProvider, db } from "./firebase";
import PairingModal from "./PairingModal"; // ← NEW IMPORT
import "./Login.css";

export default function Login({ setUser }) {
  const [userRole, setUserRole] = useState("");
  const [loading, setLoading] = useState(false);
  
  // ← NEW STATES untuk pairing system
  const [showPairingModal, setShowPairingModal] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [checkingGroup, setCheckingGroup] = useState(true);

  // ← NEW: Check login state & pairing status
  useEffect(() => {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);

        try {
          // Step 1: Check apakah user sudah punya groupId di Firestore
          const userRef = doc(db, "users", user.uid);
          const userDoc = await getDoc(userRef);

          if (userDoc.exists()) {
            // User document exists
            const userData = userDoc.data();

            if (userData.groupId) {
              // User sudah punya group → proceed to Menu
              console.log("User has group:", userData.groupId);
              
              setUser({
                uid: user.uid,
                name: userData.name || user.displayName,
                email: user.email,
                photo: userData.photo || user.photoURL,
                groupId: userData.groupId,
                role: userData.role, // "owner" atau "viewer"
              });
              setCheckingGroup(false);
            } else {
              // User document ada tapi belum punya groupId → show pairing modal
              console.log("User has no group yet");
              setShowPairingModal(true);
              setCurrentUser({
                uid: user.uid,
                name: user.displayName,
                email: user.email,
                photo: user.photoURL,
              });
              setCheckingGroup(false);
            }
          } else {
            // User document tidak ada → create dummy user document
            console.log("Creating new user document");
            
            await setDoc(userRef, {
              uid: user.uid,
              name: user.displayName,
              email: user.email,
              photo: user.photoURL,
              groupId: null, // Belum ada group
              role: null,
              createdAt: new Date(),
              updatedAt: new Date(),
            });

            // Show pairing modal
            setShowPairingModal(true);
            setCurrentUser({
              uid: user.uid,
              name: user.displayName,
              email: user.email,
              photo: user.photoURL,
            });
            setCheckingGroup(false);
          }
        } catch (error) {
          console.error("Error checking group:", error);
          alert("❌ Error checking pairing status!");
          setCheckingGroup(false);
        }
      } else {
        // User not logged in
        setCheckingGroup(false);
      }
    });
  }, [setUser]);

  // ← NEW: Handle saat owner create group
  const handleGroupCreated = (groupId) => {
    console.log("✅ Group created:", groupId);
    setShowPairingModal(false);
    
    // Bisa add "waiting for partner" screen di sini
    // Atau proceed langsung ke Menu
    // Untuk sekarang, tutup modal aja
  };

  // ← NEW: Handle saat viewer join group
  const handleGroupJoined = async (groupId) => {
    console.log("✅ Group joined:", groupId);

    try {
      // Fetch user data lagi dari Firestore (sudah update dari PairingModal)
      const userRef = doc(db, "users", currentUser.uid);
      const userDoc = await getDoc(userRef);

      if (userDoc.exists()) {
        const userData = userDoc.data();

        console.log("User data updated:", userData);

        // Set user dengan groupId terbaru
        setUser({
          uid: currentUser.uid,
          name: userData.name,
          email: currentUser.email,
          photo: userData.photo,
          groupId: userData.groupId,
          role: userData.role, // "viewer"
        });
      }
    } catch (error) {
      console.error("❌ Error fetching updated user data:", error);
      alert("Error updating user data!");
    }

    setShowPairingModal(false);
  };

  // ← MODIFIED: Google login - now simpler (pairing handled di useEffect)
  const handleGoogleLogin = async () => {
    try {
      setLoading(true);
      const result = await signInWithPopup(auth, googleProvider);
      
      // User logged in
      // useEffect will handle pairing check
      console.log("User logged in:", result.user.uid);
      
      // Simpan role ke localStorage (untuk future use)
      if (userRole) {
        localStorage.setItem("userRole", userRole);
      }
    } catch (error) {
      console.error("❌ Login failed:", error);
      alert("Login gagal! Coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  // ← NEW: Show PairingModal jika user belum punya group
  if (showPairingModal && currentUser) {
    return (
      <PairingModal
        user={{
          uid: currentUser.uid,
          name: currentUser.name,
          email: currentUser.email,
          photo: currentUser.photo,
        }}
        onGroupCreated={handleGroupCreated}
        onGroupJoined={handleGroupJoined}
      />
    );
  }

  // ← NEW: Show loading state saat checking group
  if (checkingGroup) {
    return (
      <div className="login-page">
        <div className="login-wrapper">
          <div className="login-form-section">
            <div className="login-card">
              <div className="login-header">
                <h2>Checking pairing status... 🔄</h2>
                <p>Please wait a moment</p>
              </div>
              <div className="loading-spinner"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ← ORIGINAL LOGIN UI (if user not logged in)
  return (
    <div className="login-page">
      {/* Background Elements */}
      <div className="login-bg">
        <div className="gradient-blob blob-1"></div>
        <div className="gradient-blob blob-2"></div>
        <div className="gradient-blob blob-3"></div>
      </div>

      {/* Main Container */}
      <div className="login-wrapper">
        {/* Left Side - Branding */}
        <div className="login-brand-section">
          <div className="brand-content">
            <div className="brand-logo">
              <img src="/logo_nobg.png" alt="Infinity Love" />
            </div>
            <h1 className="brand-name">Yubul</h1>
            <p className="brand-tagline">
              Tabungan berdua bareng pacar jadi makin <span>harmonis</span> 💕
            </p>

            {/* Features */}
            <div className="features-list">
              <div className="feature-item">
                <span className="feature-icon">💰</span>
                <div>
                  <p>Kelola Tabungan</p>
                  <small>Tracking uang kalian berdua dengan mudah</small>
                </div>
              </div>
              <div className="feature-item">
                <span className="feature-icon">📊</span>
                <div>
                  <p>Lihat Statistik</p>
                  <small>Analisis pengeluaran dan pemasukan realtime</small>
                </div>
              </div>
              <div className="feature-item">
                <span className="feature-icon">💕</span>
                <div>
                  <p>Transparansi</p>
                  <small>Lihat kemana uang keluar dengan jelas</small>
                </div>
              </div>
            </div>

            {/* Decorative Quote */}
            <div className="love-quote">
              <p>"Cinta + Uang Terkelola = Hubungan Sehat"</p>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="login-form-section">
          <div className="login-card">
            {/* Header */}
            <div className="login-header">
              <h2>Selamat datang di Yubul! 🎉</h2>
              <p>Mulai kelola keuangan berdua sekarang</p>
            </div>

            {/* Role Selection */}
            <div className="role-selection">
              <label className="role-label">Kamu siapa di hubungan ini? 👀</label>
              <div className="role-buttons">
                <button
                  className={`role-btn ${userRole === "cowo" ? "active" : ""}`}
                  onClick={() => setUserRole("cowo")}
                  disabled={loading}
                >
                  <span className="role-emoji">👨‍🦰</span>
                  <span>Cowo</span>
                </button>
                <button
                  className={`role-btn ${userRole === "cewe" ? "active" : ""}`}
                  onClick={() => setUserRole("cewe")}
                  disabled={loading}
                >
                  <span className="role-emoji">👩‍🦱</span>
                  <span>Cewe</span>
                </button>
              </div>
            </div>

            {/* Selected Status */}
            {userRole && (
              <div className="role-status">
                <p>
                  ✨ Mantap! Kamu pilih jadi{" "}
                  <strong>{userRole === "cowo" ? "Cowok" : "Cewe"}</strong> 💪
                </p>
              </div>
            )}

            {/* Google Login Button */}
            <button
              onClick={handleGoogleLogin}
              disabled={!userRole || loading}
              className="google-login-btn"
            >
              {loading ? (
                <>
                  <span className="spinner"></span>
                  Sedang login...
                </>
              ) : (
                <>
                  <img
                    src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
                    alt="Google"
                  />
                  Login dengan Google
                </>
              )}
            </button>

            {/* Divider */}
            <div className="divider">
              <span>atau</span>
            </div>

            {/* Terms & Security */}
            <div className="login-footer">
              <p className="security-note">
                🔒 Data kamu aman dan terenkripsi dengan Firebase
              </p>
              <p className="terms-note">
                Dengan login, kamu setuju dengan Terms & Conditions kami
              </p>
            </div>
          </div>

          {/* Floating Elements */}
          <div className="floating-elements">
            <div className="float-emoji emoji-1">💕</div>
            <div className="float-emoji emoji-2">✨</div>
            <div className="float-emoji emoji-3">💑</div>
            <div className="float-emoji emoji-4">💰</div>
          </div>
        </div>
      </div>

      {/* Mobile Responsive Note */}
      <div className="mobile-only">
        <div className="login-card-mobile">
          <div className="login-header">
            <div className="brand-logo">
              <img src="/logo_nobg.png" alt="Infinity Love" />
            </div>
            <h2>Yubul</h2>
            <p>Tabungan Berdua Jadi Harmonis</p>
          </div>

          <div className="role-selection">
            <label className="role-label">Kamu siapa? 👀</label>
            <div className="role-buttons">
              <button
                className={`role-btn ${userRole === "cowo" ? "active" : ""}`}
                onClick={() => setUserRole("cowo")}
                disabled={loading}
              >
                <span>👨‍🦰 Cowo</span>
              </button>
              <button
                className={`role-btn ${userRole === "cewe" ? "active" : ""}`}
                onClick={() => setUserRole("cewe")}
                disabled={loading}
              >
                <span>👩‍🦱 Cewe</span>
              </button>
            </div>
          </div>

          {userRole && (
            <div className="role-status">
              <p>
                ✨ Mantap! Kamu{" "}
                <strong>{userRole === "cowo" ? "Cowok" : "Cewe"}</strong> 💪
              </p>
            </div>
          )}

          <button
            onClick={handleGoogleLogin}
            disabled={!userRole || loading}
            className="google-login-btn"
          >
            {loading ? "Sedang login..." : "Login dengan Google"}
          </button>

          <p className="security-note">🔒 Data aman dengan Firebase</p>
        </div>
      </div>
    </div>
  );
}

/**
 * CHANGES MADE:
 * 
 * 1. IMPORTS (top):
 *    - Added: onAuthStateChanged, doc, getDoc, setDoc
 *    - Added: PairingModal import
 * 
 * 2. NEW STATES:
 *    - showPairingModal: Show modal jika user belum punya group
 *    - currentUser: Store current user data
 *    - checkingGroup: Loading state saat check pairing
 * 
 * 3. NEW useEffect:
 *    - Listen to auth state changes
 *    - Check Firestore: apakah user punya groupId?
 *    - NO → Show PairingModal
 *    - YES → setUser with groupId
 * 
 * 4. NEW HANDLERS:
 *    - handleGroupCreated(): Called saat owner create group
 *    - handleGroupJoined(): Called saat viewer join group
 * 
 * 5. NEW UI STATES:
 *    - If showPairingModal: Show PairingModal component
 *    - If checkingGroup: Show loading spinner
 *    - Else: Show original login UI
 * 
 * 6. MODIFIED handleGoogleLogin:
 *    - Simpler now (pairing check di useEffect)
 *    - Just handle Google login
 *    - useEffect will handle pairing
 */